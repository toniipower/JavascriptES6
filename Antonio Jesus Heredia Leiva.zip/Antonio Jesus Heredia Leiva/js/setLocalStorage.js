// setLocalStorage.js
function setLocalStorage() {
    localStorage.setItem("LoggIn", "true");
    console.log("LocalStorage set: LoggIn = true");
    window.location.href = "ejercicios/main.html";
}
