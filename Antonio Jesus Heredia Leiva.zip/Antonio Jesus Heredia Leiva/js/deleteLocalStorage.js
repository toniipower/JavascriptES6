// deleteLocalStorage.js
function deleteLocalStorage() {
    localStorage.removeItem("LoggIn");
    console.log("LocalStorage borrado: LoggIn eliminado");
}
